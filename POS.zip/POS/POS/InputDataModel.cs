﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace POS
{
    public class InputDataModel
    {
        public decimal priceItem { get; set; }
        public List<decimal> inputMoney { get; set; }       

        public InputDataModel()
        {
            inputMoney = new List<decimal>();            
        }
    }

    public static class CountryDenominations
    {
        public static List<decimal> USA = new List<decimal>() { 0.01M, 0.05M, 0.10M, 0.25M, 0.50M, 1.00M, 2.00M, 5.00M, 10.00M, 20.00M, 50.00M, 100.00M };
        public static List<decimal> Mexico = new List<decimal>() { 0.05M, 0.10M, 0.20M, 0.50M, 1.00M, 2.00M, 5.00M, 10.00M, 20.00M, 50.00M, 100.00M };
    }

    public enum errors
    {
       [Description("Price item doesn't provide")]
       NoPrice = 0,

       [Description("Bill and coins doesn't provide")]
       NoBill = 1,

       [Description("Invalid price")]
       InvalidPrice = 2,

       [Description("Not enough money")]
       NotEnoughMoney = 3,

       [Description("Invalid money")]
       InvalidMoney = 4,

        [Description("Process error")]
        ProcessError = 5,



    }
}
