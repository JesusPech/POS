﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Reflection;

namespace POS
{
    public class POS_Process
    {
        public InputDataModel inputDataModel = new InputDataModel();
        List<decimal> denominations;
        public string error { get; set; }
        public string myChangeString { get; set; }
        public List<decimal> myChangeDetail { get; set; }
        public string Country { get; set; }

        /// <summary>
        /// To add a new country denomination follow 2 steps:
        /// 1. Add new array denomination on "CountryDenominations" class 
        /// 2. Add new case on switch in "SetCountryDenomination" function
        /// 
        /// To change current country denomination change value of "Country" key in App.config. 
        /// Key value must match some case on switch in "SetCountryDenomination" function
        /// 
        /// If you set and invalid value for "Country" key in App.config, system will use default denomination on "SetCountryDenomination" function
        /// </summary>
        public POS_Process()
        {
            SetCountryDenomination();
            denominations = denominations.OrderByDescending(x => x).ToList();
            myChangeDetail = new List<decimal>();
        }

        /// <summary>
        /// This method set system money denominations based on config entry call it "Country"
        /// </summary>
        public void SetCountryDenomination()
        {
            switch (ConfigurationManager.AppSettings["Country"])
            {
                case "USA":
                    denominations = CountryDenominations.USA;
                    Country = "USA";
                    break;
                case "MEX":
                    denominations = CountryDenominations.Mexico;
                    Country = "MEXICO";
                    break;
                default:
                    denominations = CountryDenominations.USA;
                    Country = "USA";
                    break;
            }
        }

        /// <summary>
        ///  Main process. Please keep it simple!
        /// </summary>
        public void GetInputData(string priceItem, string money)
        {           
            if(validInputData(priceItem, money))            
                GetMyChange(inputDataModel.inputMoney.Sum() - inputDataModel.priceItem);
        }

        /// <summary>
        ///  Validation function for input data. If false, "error" varible will contain motive 
        /// </summary>
        public bool validInputData(string priceItem, string money)
        {
            if (string.IsNullOrEmpty(priceItem))
            {
                error = EnumExtensionMethods.GetDescription(errors.NoPrice);
                return string.IsNullOrEmpty(error);
            }


            if (string.IsNullOrEmpty(money))
            {
                error = EnumExtensionMethods.GetDescription(errors.NoBill);
                return string.IsNullOrEmpty(error);
            }

            try
            {
                if (!decimal.TryParse(priceItem, out decimal priceItem_decimal))
                {
                    error = EnumExtensionMethods.GetDescription(errors.InvalidPrice);
                    return string.IsNullOrEmpty(error);
                }
                else
                {
                    inputDataModel.priceItem = priceItem_decimal;
                }

                inputDataModel.inputMoney = money.Split(',').Select(decimal.Parse).ToList();

                if (enoughMoney())
                {
                    return true;
                }
                else
                {
                    error = EnumExtensionMethods.GetDescription(errors.NotEnoughMoney);
                    return string.IsNullOrEmpty(error);
                }
            }
            catch
            {
                error = EnumExtensionMethods.GetDescription(errors.InvalidMoney);
                return string.IsNullOrEmpty(error);
            }           
        }

        private bool enoughMoney()
        {
            return inputDataModel.inputMoney.Sum() >= inputDataModel.priceItem;
        }

        /// <summary>
        /// Should receive raw change, returns detail user's change on "myChangeDetail" and "myChangeString"
        /// </summary>
        public void GetMyChange(decimal Money)
        {
            List<decimal> myChange = new List<decimal>();
            RecursiveMoney(Money, ref myChange);
            myChangeDetail = myChange;
            GetChangeString();            
        }


        /// <summary>
        /// It calls itself until process all user's change
        /// </summary>
        private void RecursiveMoney(decimal Money, ref List<decimal> myChange)
        {
            try
            {
                decimal denomination = 0;
                denomination = denominations.Where(x => x <= Money).FirstOrDefault();
                if (denomination > 0)
                {
                    decimal howMany = Math.Truncate(Decimal.Divide(Money, denomination));
                    decimal reminder = Decimal.Remainder(Money, denomination);

                    if (howMany > 0)
                    {
                        myChange.AddRange(Enumerable.Repeat(denomination, Decimal.ToInt32(howMany)));
                        if (reminder > 0)
                            RecursiveMoney(reminder, ref myChange);
                    }
                }
            }
            catch
            {
                error = EnumExtensionMethods.GetDescription(errors.ProcessError);
            }
                    
        }


        /// <summary>
        /// Process every detail user's change and returns detail string 
        /// </summary>
        private void GetChangeString()
        {
            var query = myChangeDetail.GroupBy(x => x)              
              .Select(y => new { Element = y.Key, Counter = y.Count() })
              .ToList();

            if (myChangeDetail.Count > 0)
            {
                string result = string.Format("Your change is:{0} ", Environment.NewLine);
                string eachBill = "{0} of {1:C2}{2} ";

                foreach (var bill in query)
                {
                    result += string.Format(eachBill, bill.Counter, bill.Element, Environment.NewLine);
                }

                result += string.Format("Your total change is {0:C2}", myChangeDetail.Sum());

                myChangeString = result;

            }
            else
            {
                myChangeString = "You have no change";
            }            
        }
      
    }
}
