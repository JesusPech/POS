﻿using System;

namespace POS
{
    class Program
    {
        static void Main(string[] args)
        {
            POS_Process process = new POS_Process();
            Console.WriteLine("Welcome to POS terminal!");
            Console.WriteLine(string.Format("IMPORTANT: You are working with {0} configuration", process.Country));

            // Type your username and press enter
            Console.WriteLine("Enter price item: $");

            // Create a string variable and get user input from the keyboard and store it in the variable
            string priceItem = Console.ReadLine();

            // Print the value of the variable (userName), which will display the input value
            Console.WriteLine("Enter your money for pay, each bill and money comma separated");
            string money = Console.ReadLine();

            
            process.GetInputData(priceItem, money);

            if (string.IsNullOrEmpty(process.error))
                Console.WriteLine(process.myChangeString);
            else
                Console.WriteLine(process.error);
        }
    }
}
