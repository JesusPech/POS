using Microsoft.VisualStudio.TestTools.UnitTesting;
using POS;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace POS_TestProject
{
    [TestClass]
    public class POS_Test
    {
        [TestMethod]
        public void ValidData()
        {
            string priceItem = "400";
            string userMoney = "500";
            
            POS_Process process = new POS_Process();       

            Assert.IsTrue(process.validInputData(priceItem, userMoney));
        }

        [TestMethod]
        public void NoPriceItem_Test()
        {
            string priceItem = "";
            string userMoney = "500";

            POS_Process process = new POS_Process();
            
            Assert.IsFalse(process.validInputData(priceItem, userMoney));
            Assert.IsTrue(process.error == EnumExtensionMethods.GetDescription(errors.NoPrice));
        }

        [TestMethod]
        public void NoMoneyProvided_Test()
        {
            string priceItem = "500";
            string userMoney = "";

            POS_Process process = new POS_Process();

            Assert.IsFalse(process.validInputData(priceItem, userMoney));
            Assert.IsTrue(process.error == EnumExtensionMethods.GetDescription(errors.NoBill));
        }


        [TestMethod]
        public void NoEnoughMoney_Test()
        {
            string priceItem = "500";
            string userMoney = "20,20,.5";

            POS_Process process = new POS_Process();

            Assert.IsFalse(process.validInputData(priceItem, userMoney));
            Assert.IsTrue(process.error == EnumExtensionMethods.GetDescription(errors.NotEnoughMoney));
        }

        [TestMethod]
        public void InvalidPrice_Test()
        {
            string priceItem = "InvalidPrice";
            string userMoney = "5.6";

            POS_Process process = new POS_Process();

            Assert.IsFalse(process.validInputData(priceItem, userMoney));
            Assert.IsTrue(process.error == EnumExtensionMethods.GetDescription(errors.InvalidPrice));
        }

        [TestMethod]
        public void InvalidBills_Test()
        {
            string priceItem = "780.5";
            string userMoney = "400,2,InvalidMoney,6";

            POS_Process process = new POS_Process();

            Assert.IsFalse(process.validInputData(priceItem, userMoney));
            Assert.IsTrue(process.error == EnumExtensionMethods.GetDescription(errors.InvalidMoney));
        }   

        [TestMethod]
        public void GetChange_Test()
        {
            string priceItem = "780.30";
            string userMoney = "500,200,50,50";
            List<decimal> expected = new List<decimal>() { 10.00M, 5.00M, 2.00M, 2.00M, 0.50M, 0.10M, 0.10M};

            POS_Process process = new POS_Process();
            process.validInputData(priceItem, userMoney);
            process.GetMyChange(process.inputDataModel.inputMoney.Sum() - process.inputDataModel.priceItem);
            Assert.AreEqual(expected.Count, process.myChangeDetail.Count);
            Assert.AreEqual(expected[0], process.myChangeDetail[0]);
            Assert.AreEqual(expected[1], process.myChangeDetail[1]);
            Assert.AreEqual(expected[2], process.myChangeDetail[2]);
            Assert.AreEqual(expected[3], process.myChangeDetail[3]);
            Assert.AreEqual(expected[4], process.myChangeDetail[4]);
            Assert.AreEqual(expected[5], process.myChangeDetail[5]);
            Assert.AreEqual(expected[6], process.myChangeDetail[6]);
        }

        [TestMethod]
        public void NoChange_Test()
        {
            string priceItem = "780.30";
            string userMoney = "500,200,50,20,10,.30";
            string expected = "You have no change";

            POS_Process process = new POS_Process();
            process.validInputData(priceItem, userMoney);
            process.GetMyChange(process.inputDataModel.inputMoney.Sum() - process.inputDataModel.priceItem);
            Assert.AreEqual(expected, process.myChangeString);           
        }

    }
}
